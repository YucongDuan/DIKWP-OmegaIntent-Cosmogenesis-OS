# Public Explanation
## What was simulated?
## Which assumptions were standard science?
## Which assumptions were speculative?
## Did the model prove an ultimate purpose?
No. It compared explicit hypotheses under registered assumptions.
## What would falsify the preferred model?
## What residual uncertainty remains?
