# Model Comparison Plan
1. Freeze seed, initial conditions, gates and evaluation window.
2. Run H0 first.
3. Compare likelihood, calibration, held-out error and complexity penalty.
4. Separate observational reweighting from dynamics changes.
5. Test anthropic selection and ordinary feedback as alternatives.
6. Apply no-signalling, conservation, replayability and provenance checks.
7. Kill hypotheses without independent predictive value.
