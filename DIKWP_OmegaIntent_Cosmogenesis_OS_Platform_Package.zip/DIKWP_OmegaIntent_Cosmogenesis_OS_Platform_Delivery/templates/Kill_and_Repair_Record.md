# Kill and Repair Record
- Record ID:
- Run / hypothesis:
- Trigger / threshold / time window:
- Immediate action:
- Logs preserved:
- Root cause:
- Repair:
- Independent review:
- Re-entry conditions:
