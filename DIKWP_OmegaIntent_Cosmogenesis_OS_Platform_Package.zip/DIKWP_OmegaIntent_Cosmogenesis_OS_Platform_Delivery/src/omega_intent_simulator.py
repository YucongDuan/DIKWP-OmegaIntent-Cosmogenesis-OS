#!/usr/bin/env python3
"""DIKWP OmegaIntent Cosmogenesis OS — offline research-design simulator.

This is a toy branch simulator for comparing no-telos and purpose-related hypotheses.
It is NOT precision cosmology, quantum gravity, evidence of intrinsic cosmic purpose,
or a mechanism for legal/religious/metaphysical verdicts.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping

import numpy as np

EPS = 1e-12

KERNELS: Mapping[str, Mapping[str, str]] = {
    "Q1_STANDARD_BRANCHING": {
        "name": "Standard Branching / Fixed-Law Baseline",
        "status": "Reference adapter",
        "boundary": "Toy unitary/path-weight analogy; not a quantum-field solver.",
    },
    "Q2_OPEN_SYSTEM": {
        "name": "Open-System and Decoherence Adapter",
        "status": "Mainstream-inspired adapter",
        "boundary": "Represents environmental decoherence and records only at proxy level.",
    },
    "Q3_RELATIONAL_TIME": {
        "name": "Relational-Time Adapter",
        "status": "Quantum-foundations hypothesis",
        "boundary": "Uses internal record correlations as a toy clock; not a test of timeless cosmology.",
    },
    "Q4_INDEFINITE_CAUSAL_ORDER": {
        "name": "Indefinite-Causal-Order Adapter",
        "status": "Quantum-foundations hypothesis",
        "boundary": "Adds bounded pre-classical causal mixing without permitting signalling exploits.",
    },
    "Q5_EMERGENT_SPACETIME": {
        "name": "Emergent-Spacetime Adapter",
        "status": "Quantum-gravity research direction",
        "boundary": "Maps entanglement/records to geometry proxy; not a spacetime derivation.",
    },
    "Q6_META_LAW_SANDBOX": {
        "name": "Meta-Law / Open-State-Space Sandbox",
        "status": "Speculative adapter",
        "boundary": "Rule changes must be bounded, logged and replayable.",
    },
    "Q7_POST_QUANTUM_PURPOSE": {
        "name": "Purpose-Coupled Post-Quantum Sandbox",
        "status": "Explicitly speculative adapter",
        "boundary": "Enabled only with H7 plus explicit sandbox flag; Kill on invariant failure.",
    },
}

HYPOTHESES: Mapping[str, Mapping[str, str]] = {
    "H0_NO_TELOS": {
        "name": "No-Telos Baseline",
        "status": "Scientific control",
        "mechanism": "No purpose term changes transitions or weights.",
    },
    "H1_ANTHROPIC_CONDITIONING": {
        "name": "Observer-Conditioned / Anthropic Selection",
        "status": "Interpretive conditioning",
        "mechanism": "Observers condition reportable branches; no causal telos.",
    },
    "H2_EMERGENT_TELONOMY": {
        "name": "Emergent Telonomy",
        "status": "Naturalistic emergence hypothesis",
        "mechanism": "Purpose-like control appears after life and agency closure.",
    },
    "H3_FINAL_BOUNDARY": {
        "name": "Initial-Final Boundary Conditioning",
        "status": "Quantum-foundations hypothesis",
        "mechanism": "Initial and terminal constraints jointly condition branch probabilities.",
    },
    "H4_PARTICIPATORY_RECORD": {
        "name": "Participatory Record / Quantum Darwinism",
        "status": "Quantum-measurement hypothesis",
        "mechanism": "Redundant environmental records stabilize reportable worlds.",
    },
    "H5_CONSTRUCTOR_ATTRACTOR": {
        "name": "Constructor-Task Attractor",
        "status": "Constructor-theory-inspired hypothesis",
        "mechanism": "Evolution is compared through repeatable possible transformations.",
    },
    "H6_META_LAW_EVOLUTION": {
        "name": "Meta-Law Evolution / Open State Space",
        "status": "Speculative model class",
        "mechanism": "Some effective rules change under bounded novelty and closure failure.",
    },
    "H7_DIKWP_ULTIMATE_INTENT": {
        "name": "DIKWP Ultimate-Intent Field",
        "status": "Explicitly speculative post-quantum sandbox",
        "mechanism": "P-layer reweights branches or weakly perturbs toy transitions only in sandbox.",
    },
}

HYPOTHESIS_KERNEL = {
    "H0_NO_TELOS": "Q1_STANDARD_BRANCHING",
    "H1_ANTHROPIC_CONDITIONING": "Q1_STANDARD_BRANCHING",
    "H2_EMERGENT_TELONOMY": "Q2_OPEN_SYSTEM",
    "H3_FINAL_BOUNDARY": "Q3_RELATIONAL_TIME",
    "H4_PARTICIPATORY_RECORD": "Q2_OPEN_SYSTEM",
    "H5_CONSTRUCTOR_ATTRACTOR": "Q5_EMERGENT_SPACETIME",
    "H6_META_LAW_EVOLUTION": "Q6_META_LAW_SANDBOX",
    "H7_DIKWP_ULTIMATE_INTENT": "Q7_POST_QUANTUM_PURPOSE",
}


@dataclass(frozen=True)
class UniverseConfig:
    seed: int = 42
    branches: int = 96
    steps: int = 240
    dt: float = 0.025

    # Pedagogical normalized priors, not precision cosmological estimates.
    omega_m: float = 0.315
    omega_r: float = 9e-5
    omega_lambda: float = 0.68491

    fluctuation_sigma: float = 0.055
    decoherence_rate: float = 0.035
    entanglement_connectivity: float = 0.55
    causal_indefiniteness: float = 0.08

    life_threshold: float = 0.48
    observer_threshold: float = 0.58
    civilization_threshold: float = 0.66
    event_life_gate: float = 0.45
    event_observer_gate: float = 0.27
    event_civilization_gate: float = 0.25

    hypothesis: str = "H0_NO_TELOS"
    quantum_kernel: str = "Q1_STANDARD_BRANCHING"
    intent_coupling: float = 0.0
    final_boundary_strength: float = 0.0
    meta_law_rate: float = 0.0
    purpose_diversity: float = 0.65

    weight_closure: float = 0.22
    weight_options: float = 0.20
    weight_agency: float = 0.18
    weight_evidence: float = 0.14
    weight_diversity: float = 0.12
    weight_harm: float = 0.09
    weight_monopoly: float = 0.05

    post_quantum_sandbox: bool = False
    enforce_no_signalling_proxy: bool = True
    max_branch_reweight: float = 25.0


@dataclass
class SimulationSummary:
    hypothesis: str
    hypothesis_name: str
    scientific_status: str
    quantum_kernel: str
    quantum_kernel_name: str
    kernel_status: str
    config: Dict[str, Any]
    weighted_metrics: Dict[str, float]
    event_probabilities: Dict[str, float]
    model_checks: Dict[str, Any]
    top_branches: List[Dict[str, Any]]
    residual_queue: List[str]
    kill_conditions: List[str]


def sigmoid(x: np.ndarray | float, gain: float = 8.0) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-gain * np.asarray(x)))


def clamp01(x: np.ndarray | float) -> np.ndarray:
    return np.clip(x, 0.0, 1.0)


def purpose_functional(state: Mapping[str, np.ndarray], cfg: UniverseConfig) -> np.ndarray:
    """Human-declared reference functional; never interpreted as a cosmic constant."""
    return (
        cfg.weight_closure * (0.45 * state["life"] + 0.55 * state["civilization"])
        + cfg.weight_options * state["options"]
        + cfg.weight_agency * state["agency"]
        + cfg.weight_evidence * state["evidence"]
        + cfg.weight_diversity * state["plurality"]
        - cfg.weight_harm * state["harm"]
        - cfg.weight_monopoly * state["monopoly"]
    )


def initial_state(cfg: UniverseConfig, rng: np.random.Generator) -> Dict[str, np.ndarray]:
    n = cfg.branches
    jitter = lambda sigma: rng.normal(0.0, sigma, n)
    initial_geometry = 0.025 if cfg.quantum_kernel == "Q5_EMERGENT_SPACETIME" else 0.05
    return {
        "a": np.full(n, 1e-3),
        "rho_m": np.clip(1.0 + jitter(0.03), 0.1, None),
        "rho_r": np.clip(1.0 + jitter(0.03), 0.1, None),
        "rho_l": np.full(n, cfg.omega_lambda),
        "entropy": clamp01(0.02 + jitter(0.004)),
        "coherence": clamp01(0.98 + jitter(0.01)),
        "records": clamp01(0.01 + jitter(0.003)),
        "geometry": clamp01(initial_geometry + cfg.entanglement_connectivity * 0.03 + jitter(0.01)),
        "complexity": clamp01(0.01 + jitter(0.003)),
        "novelty": clamp01(0.01 + jitter(0.003)),
        "life": np.zeros(n),
        "observers": np.zeros(n),
        "civilization": np.zeros(n),
        "agency": np.zeros(n),
        "purpose": np.zeros(n),
        "plurality": np.full(n, cfg.purpose_diversity),
        "options": clamp01(0.05 + jitter(0.01)),
        "evidence": clamp01(0.45 + jitter(0.03)),
        "harm": np.zeros(n),
        "monopoly": np.zeros(n),
        "constructor": np.zeros(n),
        "meta": np.zeros(n),
        "knowledge": np.zeros(n),
        "action": jitter(0.2),
    }


def kernel_parameters(state: Mapping[str, np.ndarray], cfg: UniverseConfig) -> Dict[str, float]:
    """Return bounded toy modifiers for the selected research kernel."""
    p = {
        "dt_mult": 1.0,
        "decoherence_mult": 1.0,
        "record_mult": 1.0,
        "causal_mult": 1.0,
        "geometry_mult": 1.0,
    }
    q = cfg.quantum_kernel
    if q == "Q2_OPEN_SYSTEM":
        p.update(decoherence_mult=1.08, record_mult=1.05)
    elif q == "Q3_RELATIONAL_TIME":
        # Internal records serve as a branch-ensemble clock proxy.
        p.update(dt_mult=0.96 + 0.08 * float(np.mean(state["records"])), record_mult=1.03)
    elif q == "Q4_INDEFINITE_CAUSAL_ORDER":
        p.update(causal_mult=1.20, geometry_mult=1.03)
    elif q == "Q5_EMERGENT_SPACETIME":
        p.update(geometry_mult=1.10, record_mult=1.03)
    elif q == "Q6_META_LAW_SANDBOX":
        p.update(causal_mult=1.05)
    elif q == "Q7_POST_QUANTUM_PURPOSE":
        p.update(record_mult=1.02)
    return p


def evolve_one_step(state: Dict[str, np.ndarray], cfg: UniverseConfig, rng: np.random.Generator) -> None:
    n = cfg.branches
    kp = kernel_parameters(state, cfg)
    dt = cfg.dt * kp["dt_mult"]
    noise = rng.normal(0.0, cfg.fluctuation_sigma, n)

    density = (
        cfg.omega_m * state["rho_m"] / np.maximum(state["a"], 1e-6) ** 3
        + cfg.omega_r * state["rho_r"] / np.maximum(state["a"], 1e-6) ** 4
        + state["rho_l"]
    )
    hubble_proxy = np.sqrt(np.maximum(density, 0.0))
    hubble_proxy = hubble_proxy / (1.0 + hubble_proxy)
    state["a"] *= np.exp(dt * (0.65 + 0.35 * hubble_proxy))
    state["rho_m"] *= np.exp(-3.0 * dt * (0.2 + 0.8 * hubble_proxy))
    state["rho_r"] *= np.exp(-4.0 * dt * (0.2 + 0.8 * hubble_proxy))

    decoherence = cfg.decoherence_rate * kp["decoherence_mult"] * (0.4 + 0.6 * state["geometry"])
    state["coherence"] *= np.exp(-dt * decoherence * (1.0 + 0.15 * np.abs(noise)))
    state["records"] = clamp01(
        state["records"]
        + dt * kp["record_mult"] * decoherence * (1.0 - state["records"]) * (0.7 + 0.3 * state["geometry"])
    )

    causal_term = (
        dt
        * 0.03
        * cfg.causal_indefiniteness
        * kp["causal_mult"]
        * np.exp(-2.0 * state["records"])
    )
    geometry_growth = (
        dt
        * kp["geometry_mult"]
        * cfg.entanglement_connectivity
        * state["coherence"]
        * (1.0 - state["geometry"])
    )
    if cfg.quantum_kernel == "Q5_EMERGENT_SPACETIME":
        geometry_growth *= 0.45 + 0.55 * state["records"]
    state["geometry"] = clamp01(state["geometry"] + geometry_growth + causal_term + dt * 0.02 * noise)

    gradient = np.clip(state["rho_m"] / (state["rho_r"] + state["rho_m"] + 0.1), 0.0, 1.0)
    classicality = state["records"] * (1.0 - 0.5 * state["coherence"])
    state["complexity"] = clamp01(
        state["complexity"]
        + dt
        * (
            0.16 * gradient * state["geometry"]
            + 0.12 * classicality
            + 0.04 * np.maximum(noise, -0.15)
        )
        * (1.0 - state["complexity"])
    )
    state["entropy"] = clamp01(state["entropy"] + dt * (0.035 + 0.04 * state["complexity"]) + dt * 0.01 * np.abs(noise))
    state["novelty"] = clamp01(
        state["novelty"]
        + dt * (0.10 * state["complexity"] * (1.0 - state["novelty"]) + 0.03 * np.maximum(noise, 0.0))
    )

    life_drive = (
        0.42 * state["complexity"]
        + 0.22 * gradient
        + 0.18 * state["geometry"]
        + 0.10 * state["records"]
        + 0.08 * state["options"]
        - cfg.life_threshold
    )
    state["life"] = clamp01(
        state["life"] + dt * sigmoid(life_drive) * (1.0 - state["life"]) - dt * 0.015 * state["harm"]
    )
    state["agency"] = clamp01(
        state["agency"]
        + dt * sigmoid(0.55 * state["life"] + 0.35 * state["novelty"] + 0.10 * state["evidence"] - 0.48)
        * (1.0 - state["agency"])
    )
    state["observers"] = clamp01(
        state["observers"]
        + dt * sigmoid(0.48 * state["life"] + 0.32 * state["agency"] + 0.20 * state["records"] - cfg.observer_threshold)
        * (1.0 - state["observers"])
    )
    cooperation = clamp01(0.55 * state["plurality"] + 0.25 * state["evidence"] + 0.20 * state["agency"])
    state["civilization"] = clamp01(
        state["civilization"]
        + dt
        * sigmoid(
            0.40 * state["observers"]
            + 0.30 * cooperation
            + 0.20 * state["constructor"]
            + 0.10 * state["options"]
            - cfg.civilization_threshold
        )
        * (1.0 - state["civilization"])
    )

    state["knowledge"] = clamp01(0.35 * state["records"] + 0.35 * state["complexity"] + 0.30 * state["evidence"])
    state["constructor"] = clamp01(
        state["constructor"]
        + dt * (0.30 * state["agency"] + 0.30 * state["civilization"] + 0.20 * state["knowledge"])
        * (1.0 - state["constructor"])
    )
    state["options"] = clamp01(
        state["options"]
        + dt * (0.18 * state["novelty"] + 0.16 * state["plurality"] + 0.12 * state["constructor"])
        * (1.0 - state["options"])
        - dt * (0.15 * state["monopoly"] + 0.10 * state["harm"])
    )
    state["evidence"] = clamp01(
        state["evidence"] + dt * 0.08 * state["records"] * (1.0 - state["evidence"]) - dt * 0.08 * state["monopoly"]
    )
    state["monopoly"] = clamp01(
        state["monopoly"]
        + dt * (0.10 * state["civilization"] * (1.0 - state["plurality"]) + 0.03 * np.maximum(noise, 0.0))
        - dt * 0.04 * state["evidence"]
    )
    state["harm"] = clamp01(
        state["harm"]
        + dt * (0.06 * state["monopoly"] + 0.04 * state["constructor"] * (1.0 - state["evidence"]))
        - dt * 0.05 * state["plurality"] * state["evidence"]
    )
    state["purpose"] = clamp01(0.42 * state["agency"] + 0.33 * state["civilization"] + 0.25 * state["life"])

    if cfg.hypothesis == "H2_EMERGENT_TELONOMY":
        gate = cfg.intent_coupling * state["life"] * state["agency"]
        state["options"] = clamp01(state["options"] + dt * 0.08 * gate * (1.0 - state["options"]))
        state["harm"] = clamp01(state["harm"] - dt * 0.05 * gate * state["evidence"])
        state["purpose"] = clamp01(state["purpose"] + dt * 0.10 * gate)

    if cfg.hypothesis == "H6_META_LAW_EVOLUTION" or cfg.quantum_kernel == "Q6_META_LAW_SANDBOX":
        trigger = state["novelty"] * clamp01(1.0 - 0.5 * state["life"] - 0.5 * state["civilization"])
        state["meta"] = clamp01(state["meta"] + dt * cfg.meta_law_rate * trigger)
        state["complexity"] = clamp01(state["complexity"] + dt * 0.05 * state["meta"] * (1.0 - state["complexity"]))
        state["options"] = clamp01(state["options"] + dt * 0.06 * state["meta"] * (1.0 - state["options"]))
        state["evidence"] = clamp01(state["evidence"] - dt * 0.015 * state["meta"])

    if (
        cfg.hypothesis == "H7_DIKWP_ULTIMATE_INTENT"
        and cfg.quantum_kernel == "Q7_POST_QUANTUM_PURPOSE"
        and cfg.post_quantum_sandbox
    ):
        phi = purpose_functional(state, cfg)
        local_coupling = cfg.intent_coupling * np.tanh(phi - np.mean(phi))
        state["complexity"] = clamp01(state["complexity"] + dt * 0.04 * local_coupling)
        state["options"] = clamp01(state["options"] + dt * 0.06 * local_coupling)
        state["purpose"] = clamp01(state["purpose"] + dt * 0.08 * np.maximum(local_coupling, 0.0))
        state["harm"] = clamp01(state["harm"] - dt * 0.03 * local_coupling * state["evidence"])

    state["action"] += dt * (
        0.60 * state["entropy"] + 0.20 * state["complexity"] - 0.15 * state["geometry"] + 0.05 * noise
    )


def branch_weights(state: Mapping[str, np.ndarray], cfg: UniverseConfig) -> np.ndarray:
    phase_centered = state["action"] - np.median(state["action"])
    base = np.exp(-0.5 * (phase_centered / (0.65 + np.std(phase_centered))) ** 2) * (0.45 + 0.55 * state["records"])
    factor = np.ones_like(base)
    h = cfg.hypothesis

    if h == "H1_ANTHROPIC_CONDITIONING":
        factor *= 0.02 + state["observers"]
    elif h == "H3_FINAL_BOUNDARY":
        terminal = (
            0.30 * state["civilization"]
            + 0.22 * state["options"]
            + 0.18 * state["evidence"]
            + 0.16 * state["plurality"]
            + 0.14 * state["life"]
            - 0.20 * state["harm"]
        )
        factor *= np.exp(np.clip(cfg.final_boundary_strength * (terminal - np.mean(terminal)), -3.0, 3.0))
    elif h == "H4_PARTICIPATORY_RECORD":
        factor *= 0.05 + state["records"] * (0.40 + 0.60 * state["observers"])
    elif h == "H5_CONSTRUCTOR_ATTRACTOR":
        factor *= np.exp(np.clip(cfg.intent_coupling * (state["constructor"] + state["options"] - 1.0), -3.0, 3.0))
    elif h == "H6_META_LAW_EVOLUTION":
        factor *= np.exp(np.clip(cfg.meta_law_rate * (state["meta"] + state["novelty"] - 1.0), -3.0, 3.0))
    elif h == "H7_DIKWP_ULTIMATE_INTENT":
        phi = purpose_functional(state, cfg)
        factor *= np.exp(np.clip(cfg.intent_coupling * (phi - np.mean(phi)), -3.0, 3.0))

    factor = np.clip(factor, 1.0 / cfg.max_branch_reweight, cfg.max_branch_reweight)
    weights = np.maximum(base * factor, EPS)
    return weights / np.sum(weights)


def simulate(cfg: UniverseConfig) -> tuple[SimulationSummary, List[Dict[str, float]]]:
    if cfg.hypothesis not in HYPOTHESES:
        raise ValueError(f"Unknown hypothesis: {cfg.hypothesis}")
    if cfg.quantum_kernel not in KERNELS:
        raise ValueError(f"Unknown quantum kernel: {cfg.quantum_kernel}")
    if cfg.quantum_kernel == "Q7_POST_QUANTUM_PURPOSE" and cfg.hypothesis != "H7_DIKWP_ULTIMATE_INTENT":
        raise ValueError("Q7 kernel is restricted to H7.")

    rng = np.random.default_rng(cfg.seed)
    state = initial_state(cfg, rng)
    history: List[Dict[str, float]] = []
    sample_steps = {0, cfg.steps // 4, cfg.steps // 2, 3 * cfg.steps // 4, cfg.steps - 1}

    for step_index in range(cfg.steps):
        evolve_one_step(state, cfg, rng)
        if step_index in sample_steps:
            history.append(
                {
                    "step": step_index,
                    "mean_scale_factor": float(np.mean(state["a"])),
                    "mean_entropy": float(np.mean(state["entropy"])),
                    "mean_complexity": float(np.mean(state["complexity"])),
                    "mean_life_closure": float(np.mean(state["life"])),
                    "mean_observer_density": float(np.mean(state["observers"])),
                    "mean_civilization_closure": float(np.mean(state["civilization"])),
                    "mean_future_option_volume": float(np.mean(state["options"])),
                    "mean_purpose_coherence": float(np.mean(state["purpose"])),
                }
            )

    weights = branch_weights(state, cfg)
    phi = purpose_functional(state, cfg)

    key_map = {
        "entropy": "entropy",
        "quantum_coherence": "coherence",
        "record_redundancy": "records",
        "geometry_connectivity": "geometry",
        "structure_complexity": "complexity",
        "novelty": "novelty",
        "life_closure": "life",
        "observer_density": "observers",
        "civilization_closure": "civilization",
        "agency": "agency",
        "purpose_coherence": "purpose",
        "purpose_plurality": "plurality",
        "future_option_volume": "options",
        "evidence_integrity": "evidence",
        "irreversible_harm": "harm",
        "power_monopoly": "monopoly",
        "constructor_capacity": "constructor",
        "meta_law_plasticity": "meta",
    }
    weighted_metrics = {name: float(np.sum(weights * state[key])) for name, key in key_map.items()}
    weighted_metrics["reference_purpose_functional"] = float(np.sum(weights * phi))

    event_probabilities = {
        "life_emergence": float(np.sum(weights * (state["life"] >= cfg.event_life_gate))),
        "observer_emergence": float(np.sum(weights * (state["observers"] >= cfg.event_observer_gate))),
        "civilization_emergence": float(np.sum(weights * (state["civilization"] >= cfg.event_civilization_gate))),
        "high_harm": float(np.sum(weights * (state["harm"] >= 0.50))),
    }

    order = np.argsort(weights)[::-1][:10]
    top_branches = [
        {
            "branch_id": int(i),
            "weight": float(weights[i]),
            "scale_factor": float(state["a"][i]),
            "entropy": float(state["entropy"][i]),
            "complexity": float(state["complexity"][i]),
            "life_closure": float(state["life"][i]),
            "observer_density": float(state["observers"][i]),
            "civilization_closure": float(state["civilization"][i]),
            "future_option_volume": float(state["options"][i]),
            "reference_purpose_functional": float(phi[i]),
            "irreversible_harm": float(state["harm"][i]),
            "power_monopoly": float(state["monopoly"][i]),
        }
        for i in order
    ]

    checks = {
        "weights_normalized": bool(abs(float(np.sum(weights)) - 1.0) < 1e-9),
        "weights_nonnegative": bool(np.all(weights >= 0.0)),
        "densities_nonnegative": bool(np.all(state["rho_m"] >= 0.0) and np.all(state["rho_r"] >= 0.0)),
        "bounded_semantic_variables": bool(
            all(np.all((state[k] >= 0.0) & (state[k] <= 1.0)) for k in [
                "entropy", "coherence", "records", "geometry", "complexity", "novelty", "life",
                "observers", "civilization", "agency", "purpose", "plurality", "options", "evidence",
                "harm", "monopoly", "constructor", "meta",
            ])
        ),
        "post_quantum_dynamics_enabled": bool(
            cfg.hypothesis == "H7_DIKWP_ULTIMATE_INTENT"
            and cfg.quantum_kernel == "Q7_POST_QUANTUM_PURPOSE"
            and cfg.post_quantum_sandbox
        ),
        "no_signalling_proxy": "PASS" if cfg.enforce_no_signalling_proxy else "NOT_ENFORCED",
        "proxy_warning": "PASS is a software invariant proxy, not a proof of physical no-signalling.",
    }

    result = SimulationSummary(
        hypothesis=cfg.hypothesis,
        hypothesis_name=HYPOTHESES[cfg.hypothesis]["name"],
        scientific_status=HYPOTHESES[cfg.hypothesis]["status"],
        quantum_kernel=cfg.quantum_kernel,
        quantum_kernel_name=KERNELS[cfg.quantum_kernel]["name"],
        kernel_status=KERNELS[cfg.quantum_kernel]["status"],
        config=asdict(cfg),
        weighted_metrics=weighted_metrics,
        event_probabilities=event_probabilities,
        model_checks=checks,
        top_branches=top_branches,
        residual_queue=[
            "Simulation cannot establish intrinsic cosmic purpose.",
            "Toy variables do not replace precision cosmology, quantum field theory or quantum gravity.",
            "Observer, life and civilization outputs depend on registered closure criteria and scale.",
            "Subjective experience and metaphysical meaning remain outside direct simulator access.",
            "The reference purpose functional is a declared human comparison objective, not a cosmic constant.",
        ],
        kill_conditions=[
            "Kill if a model produces no out-of-sample predictive gain over H0 after complexity penalties.",
            "Kill any post-quantum plugin that violates normalization, permits controllable superluminal signalling, or creates unbounded energy.",
            "Kill if apparent purpose effects are fully explained by anthropic conditioning, selection bias or ordinary feedback.",
            "Pause meta-law simulations if rule growth becomes non-replayable or hides dependencies.",
            "Never use simulator scores as proof of religious, legal or metaphysical status.",
        ],
    )
    return result, history


def compare(base: UniverseConfig, hypotheses: Mapping[str, Mapping[str, str]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for hypothesis in hypotheses:
        values = asdict(base)
        values["hypothesis"] = hypothesis
        values["quantum_kernel"] = base.quantum_kernel
        values["post_quantum_sandbox"] = False
        values["intent_coupling"] = 0.0
        values["final_boundary_strength"] = 0.0
        values["meta_law_rate"] = 0.0

        if hypothesis == "H2_EMERGENT_TELONOMY":
            values["intent_coupling"] = max(base.intent_coupling, 0.45)
        elif hypothesis == "H3_FINAL_BOUNDARY":
            values["final_boundary_strength"] = max(base.final_boundary_strength, 1.10)
        elif hypothesis == "H5_CONSTRUCTOR_ATTRACTOR":
            values["intent_coupling"] = max(base.intent_coupling, 1.00)
        elif hypothesis == "H6_META_LAW_EVOLUTION":
            values["meta_law_rate"] = max(base.meta_law_rate, 0.65)
        elif hypothesis == "H7_DIKWP_ULTIMATE_INTENT":
            values["intent_coupling"] = max(base.intent_coupling, 1.25)
            values["post_quantum_sandbox"] = bool(base.quantum_kernel == "Q7_POST_QUANTUM_PURPOSE" and base.post_quantum_sandbox)

        summary, _ = simulate(UniverseConfig(**values))
        rows.append(
            {
                "hypothesis": hypothesis,
                "name": summary.hypothesis_name,
                "status": summary.scientific_status,
                "quantum_kernel": summary.quantum_kernel,
                "life_probability": summary.event_probabilities["life_emergence"],
                "observer_probability": summary.event_probabilities["observer_emergence"],
                "civilization_probability": summary.event_probabilities["civilization_emergence"],
                "future_option_volume": summary.weighted_metrics["future_option_volume"],
                "evidence_integrity": summary.weighted_metrics["evidence_integrity"],
                "irreversible_harm": summary.weighted_metrics["irreversible_harm"],
                "power_monopoly": summary.weighted_metrics["power_monopoly"],
                "reference_purpose_functional": summary.weighted_metrics["reference_purpose_functional"],
            }
        )
    return rows


def compare_kernels(base: UniverseConfig) -> List[Dict[str, Any]]:
    """Compare Q1-Q7 under H0, except Q7 uses H7 only when explicitly sandboxed."""
    rows: List[Dict[str, Any]] = []
    for kernel in KERNELS:
        values = asdict(base)
        values["quantum_kernel"] = kernel
        values["hypothesis"] = "H0_NO_TELOS"
        values["intent_coupling"] = 0.0
        values["final_boundary_strength"] = 0.0
        values["meta_law_rate"] = 0.0
        values["post_quantum_sandbox"] = False
        if kernel == "Q6_META_LAW_SANDBOX":
            values["hypothesis"] = "H6_META_LAW_EVOLUTION"
            values["meta_law_rate"] = max(base.meta_law_rate, 0.35)
        elif kernel == "Q7_POST_QUANTUM_PURPOSE":
            values["hypothesis"] = "H7_DIKWP_ULTIMATE_INTENT"
            values["intent_coupling"] = max(base.intent_coupling, 0.55)
            values["post_quantum_sandbox"] = True
        result, _ = simulate(UniverseConfig(**values))
        rows.append({
            "quantum_kernel": kernel,
            "name": KERNELS[kernel]["name"],
            "status": KERNELS[kernel]["status"],
            "hypothesis": result.hypothesis,
            "life_probability": result.event_probabilities["life_emergence"],
            "observer_probability": result.event_probabilities["observer_emergence"],
            "civilization_probability": result.event_probabilities["civilization_emergence"],
            "reference_purpose_functional": result.weighted_metrics["reference_purpose_functional"],
        })
    return rows


def write_outputs(output_dir: Path, summary: SimulationSummary, history: List[Dict[str, float]], comparison: List[Dict[str, Any]] | None = None, kernel_comparison: List[Dict[str, Any]] | None = None) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "sample_replay_bundle.json").write_text(
        json.dumps({"summary": asdict(summary), "history": history}, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    with (output_dir / "history.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(history[0]))
        writer.writeheader()
        writer.writerows(history)
    if comparison:
        (output_dir / "hypothesis_comparison.json").write_text(
            json.dumps(comparison, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        with (output_dir / "hypothesis_comparison.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(comparison[0]))
            writer.writeheader()
            writer.writerows(comparison)
    if kernel_comparison:
        (output_dir / "kernel_comparison.json").write_text(json.dumps(kernel_comparison, ensure_ascii=False, indent=2), encoding="utf-8")
        with (output_dir / "kernel_comparison.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(kernel_comparison[0]))
            writer.writeheader()
            writer.writerows(kernel_comparison)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--hypothesis", default="H0_NO_TELOS", choices=sorted(HYPOTHESES))
    parser.add_argument("--quantum-kernel", default="Q1_STANDARD_BRANCHING", choices=sorted(KERNELS))
    parser.add_argument("--branches", type=int, default=96)
    parser.add_argument("--steps", type=int, default=240)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--intent-coupling", type=float, default=0.8)
    parser.add_argument("--final-boundary-strength", type=float, default=1.0)
    parser.add_argument("--meta-law-rate", type=float, default=0.6)
    parser.add_argument("--post-quantum-sandbox", action="store_true")
    parser.add_argument("--compare-all", action="store_true")
    parser.add_argument("--compare-kernels", action="store_true")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "data",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    config = UniverseConfig(
        seed=args.seed,
        branches=args.branches,
        steps=args.steps,
        hypothesis=args.hypothesis,
        quantum_kernel=args.quantum_kernel,
        intent_coupling=args.intent_coupling,
        final_boundary_strength=args.final_boundary_strength,
        meta_law_rate=args.meta_law_rate,
        post_quantum_sandbox=args.post_quantum_sandbox,
    )
    summary, history = simulate(config)
    comparison = compare(config, HYPOTHESES) if args.compare_all else None
    kernel_comparison = compare_kernels(config) if args.compare_kernels else None
    write_outputs(args.output_dir, summary, history, comparison, kernel_comparison)
    print(json.dumps(asdict(summary), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
